import sys
from PyQt6.QtWidgets import QApplication
from text_editor import TextEditor

if __name__ == "__main__":
    app = QApplication(sys.argv)
    editor = TextEditor()
    editor.show()
    sys.exit(app.exec())